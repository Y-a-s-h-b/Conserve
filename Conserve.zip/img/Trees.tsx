<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Trees" tilewidth="64" tileheight="64" tilecount="30" columns="6">
 <image source="../../../../Gaming/Assets/Trees.png" width="416" height="336"/>
</tileset>
