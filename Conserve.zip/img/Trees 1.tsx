<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Trees 1" tilewidth="64" tileheight="64" tilecount="390" columns="26">
 <image source="64x64.png" width="1664" height="960"/>
</tileset>
